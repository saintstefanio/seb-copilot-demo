---
name: jira
description: Read, search, comment on, update, and transition Jira Cloud issues via the REST API when no Jira MCP server is available. Use for any request mentioning a Jira issue key (e.g. PROJ-123), a JQL query, or moving a ticket between statuses.
---

# Jira (no-MCP fallback)

Drive Jira Cloud through the CLI in this repo. It needs no Python, Node, package
install, or separately installed runtime.
Prefer a Jira MCP server if one is connected; use this when none is.

- macOS / Linux (and Git Bash / WSL): `./jira`, Bash + `curl`.
- Windows: `.\jira.ps1`, pure PowerShell. Use this when `bash` is unavailable.

Both take identical subcommands and arguments and return identical JSON.

## Setup check

Requires `JIRA_BASE_URL` plus credentials for one of two auth modes, picked
automatically:

- **Jira Cloud** (`*.atlassian.net`) — `JIRA_EMAIL` + `JIRA_API_TOKEN`, sent as
  Basic auth against REST API v3.
- **Jira Server / Data Center** (self-hosted) — `JIRA_PERSONAL_ACCESS_TOKEN`,
  sent as a Bearer token against REST API v2.

If `JIRA_PERSONAL_ACCESS_TOKEN` is set it wins and Server/DC mode is used;
otherwise the scripts fall back to Cloud mode. Nothing else changes: the
subcommands, arguments, and JSON output are identical in both modes.

Both scripts auto-load these from a `.env` file beside the script, in its parent
directory, or in the current directory; real environment variables take
precedence. If a command reports a missing variable, tell the user to set it
rather than guessing values. Cloud API tokens come from
https://id.atlassian.com/manage-profile/security/api-tokens; Server/DC personal
access tokens come from *Profile → Personal Access Tokens* on that Jira host.

A Cloud token (`ATATT…`) will **not** authenticate against a Server/DC host, and
vice versa — a 401 on every command usually means the token type does not match
the `JIRA_BASE_URL` host.

## Commands

Run from the repo root. All output is JSON.

```sh
./jira get PROJ-123
./jira search 'project = PROJ AND status = "In Progress"'
./jira comment PROJ-123 "Deploying now."
./jira update PROJ-123 '{"summary": "New summary"}'
./jira transitions PROJ-123
./jira transition PROJ-123 31
```

On Windows, swap `./jira` for `.\jira.ps1`:

```powershell
.\jira.ps1 get PROJ-123
.\jira.ps1 search 'project = PROJ AND status = "In Progress"'
```

## Rules

- **Status changes are transitions, not field writes.** Never
  `update ... '{"status": ...}'`. Run `transitions <key>` first to get the valid
  transition ids for that issue's current status, then `transition <key> <id>`.
  Transition ids differ per project and per current status — never reuse an id
  from a previous issue or from these examples.
- **Confirm before writing.** `comment`, `update`, and `transition` are visible
  to everyone on the ticket and are not cleanly undoable. Show the user the exact
  command first unless they already asked for that specific change.
- Comments are plain text; the connector wraps them in Atlassian Document Format
  on Cloud and sends them as a plain string on Server/DC.
- `search` returns 20 results by default. Narrow the JQL rather than paging.
- Quote JQL in single quotes — it contains double quotes and `=`.

## Using this skill in another repo

Copy `SKILL.md`, `jira`, and `jira.ps1` into one directory
under `.github/skills/jira/` (or `~/.copilot/skills/jira/`), and drop the
"from the repo root" qualifier — the scripts sit beside `SKILL.md`.
